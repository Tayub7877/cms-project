const router = require('express').Router()
const regc = require('../controllers/regcontroller')
const handlelogin = require('../helpers/handlelogin')


router.get('/dashboard', handlelogin, regc.dashboard)
router.get('/users', handlelogin, regc.adminusers)
router.get('/statusupdate/:id', regc.statusupdate)







module.exports = router