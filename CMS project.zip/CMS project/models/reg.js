const mongoose = require('mongoose')


const regSchema = mongoose.Schema({
    email: String,
    password: String,
    firstname: String,
    lastname: String,
    gender: String,
    dob: Date,
    createDate: { type: Date, default: new Date() },
    status: { type: String, default: 'suspended' },
    image: { type: String, default: 'default.jpg' },
    description: String,
    mobile: Number,
    address: String,
    role: { type: String, default: 'Public' }
})




module.exports = mongoose.model('reg', regSchema)