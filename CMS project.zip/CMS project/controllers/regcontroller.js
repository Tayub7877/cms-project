const Reg = require('../models/reg')
const nodemailer = require('nodemailer')
const bcrypt = require('bcrypt')

exports.loginpage = (req, res) => {
    res.render('login.ejs', { message: '' })
}
exports.registerform = (req, res) => {
    res.render('reg.ejs', { message: '' })
}
exports.singup = async (req, res) => {
    const { email, password } = req.body
    const convertedpass = await bcrypt.hash(password, 10)
    const logincheck = await Reg.findOne({ email: email })
    if (logincheck == null) {
        const record = new Reg({ email: email, password: convertedpass })
        record.save()

        const transporter = nodemailer.createTransport({
            host: "smtp.gmail.com",
            port: 587,
            secure: false,
            auth: {
                user: 'khantayub781@gmail.com',
                pass: 'owry rfgz pahb tuog',
            },
        });
        //console.log('connected to SMTP')
        const info = await transporter.sendMail({
            from: 'khantayub781@gmail.com',
            to: record.email,
            subject: 'verification link from CMS',
            text: 'Please click below to verify your account',
            html: `<a href=http://localhost:5000/emailactivation/${record.id}>Activation Link</a>`
        });
        res.render('reg.ejs', { message: 'Activation Link has been sent to your registerd email id' })
    } else {
        res.render('reg.ejs', { message: 'email id is already registered' })
    }
}
exports.emailactivation = async (req, res) => {
    const id = req.params.id
    await Reg.findByIdAndUpdate(id, { status: 'active' })
    res.render('emailverfymessage.ejs')
}
exports.logincheck = async (req, res) => {
    const { email, password } = req.body
    const record = await Reg.findOne({ email: email })
    //console.log(record)
    if (record !== null) {
        const passcheck = await bcrypt.compare(password, record.password)
        if (passcheck) {
            if (record.status == 'active') {
                req.session.email = email
                req.session.userid = record.id
                req.session.isAuth = true
                req.session.role = record.role
                if (record.email == 'admin123@gmail.com') {
                    res.redirect('/admin/dashboard')
                } else {
                    res.redirect('/profiles')
                }
            } else {
                res.render('login.ejs', { message: 'Your Account is Suspended. Please valid your email first' })
            }
        } else {
            res.render('login.ejs', { message: 'Wrong password' })
        }
    } else {
        res.render('login.ejs', { message: 'Wrong Username' })
    }
}
exports.dashboard = (req, res) => {
    const email = req.session.email
    res.render('admin/dashboard.ejs', { email })
}
exports.logout = (req, res) => {
    req.session.destroy()
    res.redirect('/')
}
exports.adminusers = async (req, res) => {
    const email = req.session.email
    const record = await Reg.find()
    res.render('admin/users.ejs', { email, record })
}
exports.profiles = async (req, res) => {
    const email = req.session.email
    const record = await Reg.find({ image: { $nin: ['default.jpg'] } })
    res.render('profiles.ejs', { email, record })
}
exports.profileupdateform = async (req, res) => {
    const email = req.session.email
    const record = await Reg.findOne({ email: email })
    res.render('updateprofileform.ejs', { email, record })
}
exports.profileupdate = async (req, res) => {
    const { firstname, lastname, gender, description, address, mobile } = req.body
    const id = req.session.userid
    if (req.file) {
        const filename = req.file.filename
        await Reg.findByIdAndUpdate(id, { firstname: firstname, lastname: lastname, gender: gender, image: filename, description: description, address: address, mobile: mobile })
    } else {
        await Reg.findByIdAndUpdate(id, { firstname: firstname, description: description, lastname: lastname, gender: gender, address: address, mobile: mobile })
    }
    res.redirect('/profileupdate')
}
exports.statusupdate = async (req, res) => {
    const id = req.params.id
    const record = await Reg.findById(id)
    let newstatus = null
    if (record.status == 'suspended') {
        newstatus = 'active'
    } else {
        newstatus = 'suspended'
    }
    await Reg.findByIdAndUpdate(id, { status: newstatus })
    res.redirect('/admin/users')
}
exports.contactdetail = async (req, res) => {
    const email = req.session.email
    const id = req.params.id
    const record = await Reg.findById(id)
    res.render('contact.ejs', { email, record })
}
exports.forgotform = (req, res) => {
    res.render('forgotform.ejs', { message: '' })
}
exports.forgotlink = async (req, res) => {
    const { email } = req.body
    const record = await Reg.findOne({ email: email })
    if (record == null) {
        res.render('forgotform.ejs', { message: 'Email not found' })
    } else {
        const transporter = nodemailer.createTransport({
            host: "smtp.gmail.com",
            port: 587,
            secure: false,
            auth: {
                user: 'khantayub781@gmail.com',
                pass: 'owry rfgz pahb tuog',
            },
        });
        //console.log('connected to SMTP')
        const info = await transporter.sendMail({
            from: 'khantayub781@gmail.com',
            to: email,
            subject: 'Change Password from cms project',
            text: 'Please click below to generate new Password',
            html: `<a href=http://localhost:5000/forgotchangepassword/${record.id}>Click to generate new password</a>`
        });
        console.log('email sent')
        res.render('forgotform.ejs', { message: 'Email link has been sent to registerd email' })
    }
}
exports.forgotpasswordchangeform = (req, res) => {
    res.render('forgotpass.ejs', { message: '' })
}
exports.forpasscha = async (req, res) => {
    const id = req.params.id
    const { npass, cpass } = req.body
    if (npass == cpass) {
        const convertedpass = await bcrypt.hash(npass, 10)
        await Reg.findByIdAndUpdate(id, { password: convertedpass })
        res.render('forgotmassage.ejs')
    } else {
        res.render('forgotpass.ejs', { message: 'password not matched' })
    }
}
