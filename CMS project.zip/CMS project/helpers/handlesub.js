function handlesub(req, res, next) {
    if (req.session.role == 'Pvt') {
        next()
    } else {
        res.render('subscriptionmsg.ejs')
    }
}
module.exports = handlesub